# RubyLatex
This is the TeX side to the rubylatex package. You can install this, but it will be useless unless
you have a Ruby distribution **and** you have installed the `rbtex` gem from rubygems.

The official repository is located [here](https://github.com/RubyLatex/RbTeX).
